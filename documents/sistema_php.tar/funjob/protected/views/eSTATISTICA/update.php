<h2>ALTERAR REGISTRO #<?php echo $model->idestatistica; ?></h2>

<?php echo $this->renderPartial('_form', array(
	'model'=>$model,
	'update'=>true,
)); ?> 